import { Module } from '@nestjs/common';
import { TechnicalComplianceAssessmentsController } from "./controllers";
import { TechnicalComplianceAssessmentsService } from "./services";
import { TypeOrmModule } from '@nestjs/typeorm';
import { TechnicalComplianceAssessments } from "src/entities";

@Module({
  imports: [TypeOrmModule.forFeature([TechnicalComplianceAssessments])],
  controllers: [TechnicalComplianceAssessmentsController],
  providers: [TechnicalComplianceAssessmentsService],
})
export class TechnicalComplianceAssessmentsModule {}
