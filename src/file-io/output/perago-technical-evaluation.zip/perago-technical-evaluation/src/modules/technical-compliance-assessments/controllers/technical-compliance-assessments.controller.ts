import { Controller } from '@nestjs/common';
import { ExtraCrudController } from 'src/shared/controller';
import { ExtraCrudOptions } from 'src/shared/types/crud-option.type
import { CreateTechnicalComplianceAssessmentsDto, UpdateTechnicalComplianceAssessmentsDto } from "../../dtos";
import { TechnicalComplianceAssessmentsService } from "../services";


const options: ExtraCrudOptions = {
  entityIdName: '',
  createDto: CreateTechnicalComplianceAssessmentsDto,
};

@Controller('technical-compliance-assessments')
export class TechnicalComplianceAssessmentsController extends ExtraCrudController<TechnicalComplianceAssessments>(
  options,
) {
  constructor(
    private readonly technicalComplianceAssessmentsService: TechnicalComplianceAssessmentsService,
  ) {
    super(technicalComplianceAssessmentsService);
  }

}
