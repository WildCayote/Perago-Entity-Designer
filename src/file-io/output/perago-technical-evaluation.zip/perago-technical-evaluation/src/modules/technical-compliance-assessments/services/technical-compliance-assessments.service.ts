import { InjectRepository } from '@nestjs/typeorm';
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { ExtraCrudService } from 'src/shared/service';
import {  CreateTechnicalComplianceAssessmentsDto, UpdateTechnicalComplianceAssessmentsDto } from "../../dtos";
import { TechnicalComplianceAssessments } from "../../entities";

@Injectable()
export class TechnicalComplianceAssessmentsService extends ExtraCrudService<TechnicalComplianceAssessments> {
  constructor(
    @InjectRepository(TechnicalComplianceAssessments)
    private readonly technicalComplianceAssessmentsRepository: Repository<TechnicalComplianceAssessments>,
  ) {
    super(technicalComplianceAssessmentsRepository);
  }

  }

