import { Controller } from '@nestjs/common';
import { ExtraCrudController } from 'src/shared/controller';
import { ExtraCrudOptions } from 'src/shared/types/crud-option.type
import { CreateTechnicalQualificationEvaluationDto, UpdateTechnicalQualificationEvaluationDto } from "../../dtos";
import { TechnicalQualificationEvaluationService } from "../services";


const options: ExtraCrudOptions = {
  entityIdName: '',
  createDto: CreateTechnicalQualificationEvaluationDto,
};

@Controller('technical-qualification-evaluation')
export class TechnicalQualificationEvaluationController extends ExtraCrudController<TechnicalQualificationEvaluation>(
  options,
) {
  constructor(
    private readonly technicalQualificationEvaluationService: TechnicalQualificationEvaluationService,
  ) {
    super(technicalQualificationEvaluationService);
  }

}
