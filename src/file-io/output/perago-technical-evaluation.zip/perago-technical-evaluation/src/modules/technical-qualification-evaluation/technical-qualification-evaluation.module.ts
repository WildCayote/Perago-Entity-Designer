import { Module } from '@nestjs/common';
import { TechnicalQualificationEvaluationController } from "./controllers";
import { TechnicalQualificationEvaluationService } from "./services";
import { TypeOrmModule } from '@nestjs/typeorm';
import { TechnicalQualificationEvaluation } from "src/entities";

@Module({
  imports: [TypeOrmModule.forFeature([TechnicalQualificationEvaluation])],
  controllers: [TechnicalQualificationEvaluationController],
  providers: [TechnicalQualificationEvaluationService],
})
export class TechnicalQualificationEvaluationModule {}
