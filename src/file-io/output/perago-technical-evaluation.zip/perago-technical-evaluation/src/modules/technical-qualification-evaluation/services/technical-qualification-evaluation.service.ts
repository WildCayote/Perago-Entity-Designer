import { InjectRepository } from '@nestjs/typeorm';
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { ExtraCrudService } from 'src/shared/service';
import {  CreateTechnicalQualificationEvaluationDto, UpdateTechnicalQualificationEvaluationDto } from "../../dtos";
import { TechnicalQualificationEvaluation } from "../../entities";

@Injectable()
export class TechnicalQualificationEvaluationService extends ExtraCrudService<TechnicalQualificationEvaluation> {
  constructor(
    @InjectRepository(TechnicalQualificationEvaluation)
    private readonly technicalQualificationEvaluationRepository: Repository<TechnicalQualificationEvaluation>,
  ) {
    super(technicalQualificationEvaluationRepository);
  }

  }

