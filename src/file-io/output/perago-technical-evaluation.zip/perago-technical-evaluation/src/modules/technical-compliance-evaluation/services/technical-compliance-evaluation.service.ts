import { InjectRepository } from '@nestjs/typeorm';
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { ExtraCrudService } from 'src/shared/service';
import {  CreateTechnicalComplianceEvaluationDto, UpdateTechnicalComplianceEvaluationDto } from "../../dtos";
import { TechnicalComplianceEvaluation } from "../../entities";

@Injectable()
export class TechnicalComplianceEvaluationService extends ExtraCrudService<TechnicalComplianceEvaluation> {
  constructor(
    @InjectRepository(TechnicalComplianceEvaluation)
    private readonly technicalComplianceEvaluationRepository: Repository<TechnicalComplianceEvaluation>,
  ) {
    super(technicalComplianceEvaluationRepository);
  }

  }

