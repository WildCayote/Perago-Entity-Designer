import { Module } from '@nestjs/common';
import { TechnicalComplianceEvaluationController } from "./controllers";
import { TechnicalComplianceEvaluationService } from "./services";
import { TypeOrmModule } from '@nestjs/typeorm';
import { TechnicalComplianceEvaluation } from "src/entities";

@Module({
  imports: [TypeOrmModule.forFeature([TechnicalComplianceEvaluation])],
  controllers: [TechnicalComplianceEvaluationController],
  providers: [TechnicalComplianceEvaluationService],
})
export class TechnicalComplianceEvaluationModule {}
