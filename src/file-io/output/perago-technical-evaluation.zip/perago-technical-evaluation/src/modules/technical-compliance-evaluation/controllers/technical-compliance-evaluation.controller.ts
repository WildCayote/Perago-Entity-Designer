import { Controller } from '@nestjs/common';
import { ExtraCrudController } from 'src/shared/controller';
import { ExtraCrudOptions } from 'src/shared/types/crud-option.type
import { CreateTechnicalComplianceEvaluationDto, UpdateTechnicalComplianceEvaluationDto } from "../../dtos";
import { TechnicalComplianceEvaluationService } from "../services";


const options: ExtraCrudOptions = {
  entityIdName: '',
  createDto: CreateTechnicalComplianceEvaluationDto,
};

@Controller('technical-compliance-evaluation')
export class TechnicalComplianceEvaluationController extends ExtraCrudController<TechnicalComplianceEvaluation>(
  options,
) {
  constructor(
    private readonly technicalComplianceEvaluationService: TechnicalComplianceEvaluationService,
  ) {
    super(technicalComplianceEvaluationService);
  }

}
