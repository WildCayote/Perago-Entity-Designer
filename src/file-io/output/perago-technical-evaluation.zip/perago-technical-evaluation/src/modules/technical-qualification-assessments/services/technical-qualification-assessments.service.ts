import { InjectRepository } from '@nestjs/typeorm';
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { ExtraCrudService } from 'src/shared/service';
import {  CreateTechnicalQualificationAssessmentsDto, UpdateTechnicalQualificationAssessmentsDto } from "../../dtos";
import { TechnicalQualificationAssessments } from "../../entities";

@Injectable()
export class TechnicalQualificationAssessmentsService extends ExtraCrudService<TechnicalQualificationAssessments> {
  constructor(
    @InjectRepository(TechnicalQualificationAssessments)
    private readonly technicalQualificationAssessmentsRepository: Repository<TechnicalQualificationAssessments>,
  ) {
    super(technicalQualificationAssessmentsRepository);
  }

  }

