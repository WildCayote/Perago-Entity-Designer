import { Controller } from '@nestjs/common';
import { ExtraCrudController } from 'src/shared/controller';
import { ExtraCrudOptions } from 'src/shared/types/crud-option.type
import { CreateTechnicalQualificationAssessmentsDto, UpdateTechnicalQualificationAssessmentsDto } from "../../dtos";
import { TechnicalQualificationAssessmentsService } from "../services";


const options: ExtraCrudOptions = {
  entityIdName: '',
  createDto: CreateTechnicalQualificationAssessmentsDto,
};

@Controller('technical-qualification-assessments')
export class TechnicalQualificationAssessmentsController extends ExtraCrudController<TechnicalQualificationAssessments>(
  options,
) {
  constructor(
    private readonly technicalQualificationAssessmentsService: TechnicalQualificationAssessmentsService,
  ) {
    super(technicalQualificationAssessmentsService);
  }

}
