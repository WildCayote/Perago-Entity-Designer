import { Module } from '@nestjs/common';
import { TechnicalQualificationAssessmentsController } from "./controllers";
import { TechnicalQualificationAssessmentsService } from "./services";
import { TypeOrmModule } from '@nestjs/typeorm';
import { TechnicalQualificationAssessments } from "src/entities";

@Module({
  imports: [TypeOrmModule.forFeature([TechnicalQualificationAssessments])],
  controllers: [TechnicalQualificationAssessmentsController],
  providers: [TechnicalQualificationAssessmentsService],
})
export class TechnicalQualificationAssessmentsModule {}
