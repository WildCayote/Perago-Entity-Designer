import { IsString, IsNumber, IsBoolean, IsOptional, IsArray, IsEnum } from
'class-validator'; import { PartialType } from '@nestjs/mapped-types'; export
class CreateTechnicalComplianceAssessmentsDto {
    @IsString()

  LotId:
  string;
    @IsString()

  BidderId:
  string;
    @IsString()

  TeamId:
  string;
    @IsString()

  EvaluatorId:
  string;
    @IsBoolean()

  IsTeamAssessment:
  boolean;
    @IsString()

  Status:
  string;
    @IsNumber()

  ApprovalStatus:
  number;
    @IsNumber()

  Version:
  number;
} export class UpdateTechnicalComplianceAssessmentsDto extends PartialType(CreateTechnicalComplianceAssessmentsDto) {}