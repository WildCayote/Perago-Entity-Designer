import { IsString, IsNumber, IsBoolean, IsOptional, IsArray, IsEnum } from
'class-validator'; import { PartialType } from '@nestjs/mapped-types'; export
class CreateTechnicalComplianceEvaluationDto {
    @IsString()

  AssessmentId:
  string;
    @IsString()

  CriterionId:
  string;
    @IsString()
    @IsOptional()

  Tag:
  string;
    @IsString()

  Status:
  string;
    @IsString()
    @IsOptional()

  Remark:
  string;
    @IsString()

  Requirement:
  string;
    @IsString()

  RequirementCondition:
  string;
    @IsString()
    @IsOptional()

  AdditionalRequirements:
  string;
    @IsString()

  SectionLink:
  string;
    @IsString()
    @IsOptional()

  Value:
  string;
} export class UpdateTechnicalComplianceEvaluationDto extends PartialType(CreateTechnicalComplianceEvaluationDto) {}