import { IsString, IsNumber, IsBoolean, IsOptional, IsArray, IsEnum } from
'class-validator'; import { PartialType } from '@nestjs/mapped-types'; export
class CreateTechnicalQualificationEvaluationDto {
    @IsString()

  assessmentId:
  string;
    @IsString()

  qualificationType:
  string;
    @IsString()

  criterionId:
  string;
    @IsString()
    @IsOptional()

  tag:
  string;
    @IsString()

  status:
  string;
    @IsString()
    @IsOptional()

  remark:
  string;
    @IsString()

  requirement:
  string;
    @IsString()

  requirementCondition:
  string;
    @IsString()
    @IsOptional()

  additionalRequirements:
  string;
    @IsString()

  sectionLink:
  string;
    @IsOptional()

  jvCombinedCondition:
  jsonb;
    @IsOptional()

  jvEachPartnerCondition:
  jsonb;
    @IsOptional()

  jvAtleastOnePartnerCondition:
  jsonb;
    @IsOptional()

  singleEntityCondition:
  jsonb;
    @IsOptional()

  value:
  text;
} export class UpdateTechnicalQualificationEvaluationDto extends PartialType(CreateTechnicalQualificationEvaluationDto) {}