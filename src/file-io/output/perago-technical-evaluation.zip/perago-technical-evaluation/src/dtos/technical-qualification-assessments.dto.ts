import { IsString, IsNumber, IsBoolean, IsOptional, IsArray, IsEnum } from
'class-validator'; import { PartialType } from '@nestjs/mapped-types'; export
class CreateTechnicalQualificationAssessmentsDto {
    @IsString()

  teamId:
  string;
    @IsString()

  evaluatorId:
  string;
    @IsString()

  bidderId:
  string;
    @IsBoolean()

  isTeamAssessment:
  boolean;
    @IsString()

  legalQualificationAssessmentStatus:
  string;
    @IsString()

  professionalQualificationAssessmentStatus:
  string;
    @IsString()

  technicalQualificationAssessmentStatus:
  string;
    @IsString()

  financialQualificationAssessmentStatus:
  string;
    @IsString()

  performanceQualificationAssessmentStatus:
  string;
    @IsNumber()

  legalQualificationApprovalStatus:
  number;
    @IsNumber()

  professionalQualificationApprovalStatus:
  number;
    @IsNumber()

  technicalQualificationApprovalStatus:
  number;
    @IsNumber()

  financialQualificationApprovalStatus:
  number;
    @IsNumber()

  performanceQualificationApprovalStatus:
  number;
    @IsNumber()

  version:
  number;
    @IsString()

  username:
  string;
} export class UpdateTechnicalQualificationAssessmentsDto extends PartialType(CreateTechnicalQualificationAssessmentsDto) {}