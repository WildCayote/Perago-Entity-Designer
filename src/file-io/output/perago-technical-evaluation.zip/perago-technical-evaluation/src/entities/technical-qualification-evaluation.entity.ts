import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';


@Entity()
export class TechnicalQualificationEvaluation {

  @PrimaryGeneratedColumn("uuid")
  id: string;
  

    @Column({
      nullable: false,
    })
    assessmentId: string;
    @Column({
      nullable: false,
    })
    qualificationType: string;
    @Column({
      nullable: false,
    })
    criterionId: string;
    @Column({
      nullable: true,
    })
    tag: string;
    @Column({
      nullable: false,
    })
    status: string;
    @Column({
      nullable: true,
    })
    remark: string;
    @Column({
      nullable: false,
    })
    requirement: string;
    @Column({
      nullable: false,
    })
    requirementCondition: string;
    @Column({
      nullable: true,
    })
    additionalRequirements: string;
    @Column({
      nullable: false,
    })
    sectionLink: string;
    @Column({
      nullable: true,
    })
    jvCombinedCondition: jsonb;
    @Column({
      nullable: true,
    })
    jvEachPartnerCondition: jsonb;
    @Column({
      nullable: true,
    })
    jvAtleastOnePartnerCondition: jsonb;
    @Column({
      nullable: true,
    })
    singleEntityCondition: jsonb;
    @Column({
      nullable: true,
    })
    value: text;



}
