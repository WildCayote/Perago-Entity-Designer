import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';


@Entity()
export class TechnicalQualificationAssessments {

  @PrimaryGeneratedColumn("uuid")
  id: string;
  

    @Column({
      nullable: false,
    })
    teamId: string;
    @Column({
      nullable: false,
    })
    evaluatorId: string;
    @Column({
      nullable: false,
    })
    bidderId: string;
    @Column({
      nullable: false,
    })
    isTeamAssessment: boolean;
    @Column({
      nullable: false,
    })
    legalQualificationAssessmentStatus: string;
    @Column({
      nullable: false,
    })
    professionalQualificationAssessmentStatus: string;
    @Column({
      nullable: false,
    })
    technicalQualificationAssessmentStatus: string;
    @Column({
      nullable: false,
    })
    financialQualificationAssessmentStatus: string;
    @Column({
      nullable: false,
    })
    performanceQualificationAssessmentStatus: string;
    @Column({
      nullable: false,
    })
    legalQualificationApprovalStatus: number;
    @Column({
      nullable: false,
    })
    professionalQualificationApprovalStatus: number;
    @Column({
      nullable: false,
    })
    technicalQualificationApprovalStatus: number;
    @Column({
      nullable: false,
    })
    financialQualificationApprovalStatus: number;
    @Column({
      nullable: false,
    })
    performanceQualificationApprovalStatus: number;
    @Column({
      nullable: false,
    })
    version: number;
    @Column({
      nullable: false,
      unique: true, 
    })
    username: string;



}
