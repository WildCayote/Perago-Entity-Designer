import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';


@Entity()
export class TechnicalComplianceAssessments {

  @PrimaryGeneratedColumn("uuid")
  id: string;
  

    @Column({
      nullable: false,
    })
    lotid: string;
    @Column({
      nullable: false,
    })
    bidderid: string;
    @Column({
      nullable: false,
    })
    teamid: string;
    @Column({
      nullable: false,
    })
    evaluatorid: string;
    @Column({
      nullable: false,
    })
    isteamassessment: boolean;
    @Column({
      nullable: false,
    })
    status: string;
    @Column({
      nullable: false,
    })
    approvalstatus: number;
    @Column({
      nullable: false,
    })
    version: number;



}
