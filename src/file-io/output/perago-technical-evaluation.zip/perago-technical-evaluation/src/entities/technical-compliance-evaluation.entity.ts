import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';


@Entity()
export class TechnicalComplianceEvaluation {

  @PrimaryGeneratedColumn("uuid")
  Id: string;
  

    @Column({
      nullable: false,
    })
    assessmentid: string;
    @Column({
      nullable: false,
    })
    criterionid: string;
    @Column({
      nullable: true,
    })
    tag: string;
    @Column({
      nullable: false,
    })
    status: string;
    @Column({
      nullable: true,
    })
    remark: string;
    @Column({
      nullable: false,
    })
    requirement: string;
    @Column({
      nullable: false,
    })
    requirementcondition: string;
    @Column({
      nullable: true,
    })
    additionalrequirements: string;
    @Column({
      nullable: false,
    })
    sectionlink: string;
    @Column({
      nullable: true,
    })
    value: string;



}
