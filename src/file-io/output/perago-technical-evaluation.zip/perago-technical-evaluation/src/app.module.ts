import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';


    import { TechnicalComplianceAssessmentsModule } from "./technical-compliance-assessments";
    import { TechnicalComplianceEvaluationModule } from "./technical-compliance-evaluation";
    import { TechnicalQualificationAssessmentsModule } from "./technical-qualification-assessments";
    import { TechnicalQualificationEvaluationModule } from "./technical-qualification-evaluation";



import { 
  TechnicalComplianceAssessments,  
  TechnicalComplianceEvaluation,  
  TechnicalQualificationAssessments,  
  TechnicalQualificationEvaluation, 
} from "./entities";

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'your_username',
      password: 'your_password',
      database: 'your_database',
      entities: [
        TechnicalComplianceAssessments, 
        TechnicalComplianceEvaluation, 
        TechnicalQualificationAssessments, 
        TechnicalQualificationEvaluation
      ],
      synchronize: true,
    }),
    TechnicalComplianceAssessmentsModule,
    TechnicalComplianceEvaluationModule,
    TechnicalQualificationAssessmentsModule,
    TechnicalQualificationEvaluationModule
  ],
})
export class AppModule {}
