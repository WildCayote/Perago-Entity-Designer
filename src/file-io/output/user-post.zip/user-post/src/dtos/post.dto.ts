import { IsString, IsNumber, IsBoolean, IsOptional, IsArray, IsEnum } from
'class-validator'; import { PartialType } from '@nestjs/mapped-types'; export
class CreatePostDto {
    @IsString()

  content:
  string;
    @IsString()
    @IsOptional()

  title:
  string;
} export class UpdatePostDto extends PartialType(CreatePostDto) {}