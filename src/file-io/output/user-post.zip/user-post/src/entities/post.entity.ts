import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
  import { ManyToOne } from 'typeorm';
    import { User } from './user.entity'; 


@Entity()
export class Post {

  @PrimaryGeneratedColumn("uuid")
  id: string;
  

    @Column({
      nullable: false,
    })
    content: string;
    @Column({
      nullable: true,
    })
    title: string;

    @ManyToOne(() => User, (user) => user.posts)
    
    user: string;


}
