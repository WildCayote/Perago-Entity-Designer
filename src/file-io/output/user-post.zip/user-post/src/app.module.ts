import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';


    import { UserModule } from "./user";
    import { PostModule } from "./post";



import { 
  User,  
  Post, 
} from "./entities";

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'your_username',
      password: 'your_password',
      database: 'your_database',
      entities: [
        User, 
        Post
      ],
      synchronize: true,
    }),
    UserModule,
    PostModule
  ],
})
export class AppModule {}
