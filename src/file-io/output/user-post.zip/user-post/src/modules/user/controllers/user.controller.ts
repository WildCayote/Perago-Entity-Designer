import { Controller } from '@nestjs/common';
import { ExtraCrudController } from 'src/shared/controller';
import { ExtraCrudOptions } from 'src/shared/types/crud-option.type
import { CreateUserDto, UpdateUserDto } from "../../dtos";
import { UserService } from "../services";


const options: ExtraCrudOptions = {
  entityIdName: '',
  createDto: CreateUserDto,
};

@Controller('user')
export class UserController extends ExtraCrudController<User>(
  options,
) {
  constructor(
    private readonly userService: UserService,
  ) {
    super(userService);
  }

}
