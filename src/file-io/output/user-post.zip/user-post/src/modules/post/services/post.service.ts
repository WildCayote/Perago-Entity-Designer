import { InjectRepository } from '@nestjs/typeorm';
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { ExtraCrudService } from 'src/shared/service';
import {  CreatePostDto, UpdatePostDto } from "../../dtos";
import { Post } from "../../entities";

@Injectable()
export class PostService extends ExtraCrudService<Post> {
  constructor(
    @InjectRepository(Post)
    private readonly postRepository: Repository<Post>,
  ) {
    super(postRepository);
  }

  }

