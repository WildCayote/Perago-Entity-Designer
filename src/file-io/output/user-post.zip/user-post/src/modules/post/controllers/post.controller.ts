import { Controller } from '@nestjs/common';
import { ExtraCrudController } from 'src/shared/controller';
import { ExtraCrudOptions } from 'src/shared/types/crud-option.type
import { CreatePostDto, UpdatePostDto } from "../../dtos";
import { PostService } from "../services";


const options: ExtraCrudOptions = {
  entityIdName: '',
  createDto: CreatePostDto,
};

@Controller('post')
export class PostController extends ExtraCrudController<Post>(
  options,
) {
  constructor(
    private readonly postService: PostService,
  ) {
    super(postService);
  }

}
