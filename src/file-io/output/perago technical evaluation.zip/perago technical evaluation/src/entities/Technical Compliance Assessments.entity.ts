


@Entity()
export class Technical Compliance Assessments {

 @PrimaryGeneratedColumn("uuid")
 id: string;

    @Column({
      nullable: false,
    })
    LotId: string;
    @Column({
      nullable: false,
    })
    BidderId: string;
    @Column({
      nullable: false,
    })
    TeamId: string;
    @Column({
      nullable: false,
    })
    EvaluatorId: string;
    @Column({
      nullable: false,
    })
    IsTeamAssessment: boolean;
    @Column({
      nullable: false,
    })
    Status: string;
    @Column({
      nullable: false,
    })
    ApprovalStatus: number;
    @Column({
      nullable: false,
    })
    Version: number;



}
