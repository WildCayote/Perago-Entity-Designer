import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';


    import { Technical Compliance AssessmentsModule } from "./technical-compliance-assessments";



import { 
  Technical Compliance Assessments, 
} from "./entities";

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'your_username',
      password: 'your_password',
      database: 'your_database',
      entities: [
        Technical Compliance Assessments
      ],
      synchronize: true,
    }),
    Technical Compliance AssessmentsModule
  ],
})
export class AppModule {}
