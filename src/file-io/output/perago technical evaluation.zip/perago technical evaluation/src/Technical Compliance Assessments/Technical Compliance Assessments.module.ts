import { Module } from '@nestjs/common';
import { Technical Compliance AssessmentsController } from "./controllers";
import { Technical Compliance AssessmentsService } from "./services";
import { TypeOrmModule } from '@nestjs/typeorm';
import { Technical Compliance Assessments } from "src/entities";

@Module({
  imports: [TypeOrmModule.forFeature([Technical Compliance Assessments])],
  controllers: [Technical Compliance AssessmentsController],
  providers: [Technical Compliance AssessmentsService],
})
export class Technical Compliance AssessmentsModule {}
