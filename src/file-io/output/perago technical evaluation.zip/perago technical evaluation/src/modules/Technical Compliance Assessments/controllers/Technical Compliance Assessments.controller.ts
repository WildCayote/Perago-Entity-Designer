import { Controller } from '@nestjs/common';
import { ExtraCrudController } from 'src/shared/controller';
import { ExtraCrudOptions } from 'src/shared/types/crud-option.type
import { CreateTechnical Compliance AssessmentsDto, UpdateTechnical Compliance AssessmentsDto } from "../../dtos";
import { Technical Compliance AssessmentsService } from "../services";


const options: ExtraCrudOptions = {
  entityIdName: '',
  createDto: CreateTechnical Compliance AssessmentsDto,
};

@Controller('technical-compliance-assessments')
export class Technical Compliance AssessmentsController extends ExtraCrudController<Technical Compliance Assessments>(
  options,
) {
  constructor(
    private readonly technicalComplianceAssessmentsService: Technical Compliance AssessmentsService,
  ) {
    super(technicalComplianceAssessmentsService);
  }

}
