import { InjectRepository } from '@nestjs/typeorm';
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { ExtraCrudService } from 'src/shared/service';
import {  CreateTechnical Compliance AssessmentsDto, UpdateTechnical Compliance AssessmentsDto } from "../../dtos";
import { Technical Compliance Assessments } from "../../entities";

@Injectable()
export class Technical Compliance AssessmentsService extends ExtraCrudService<Technical Compliance Assessments> {
  constructor(
    @InjectRepository(Technical Compliance Assessments)
    private readonly technicalComplianceAssessmentsRepository: Repository<Technical Compliance Assessments>,
  ) {
    super(technicalComplianceAssessmentsRepository);
  }

  }

